package edu.iastate.cs228.hw4;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This class is the main. It asks the user for a file, then retrieves the file. It then calls  MsgTree and encodes the message
 
 * 
 * @author Braydon Clay
 *
 */
public class Main {
	public static void main(String[] args) throws IOException {
		System.out.println("Please enter filename to decode:");
		Scanner scanner = new Scanner(System.in);
		String fileName = scanner.nextLine();
		scanner.close();

		//Reads in all the chars
		String content = new String(Files.readAllBytes(Paths.get(fileName))).trim();
		int current = content.lastIndexOf('\n');
		String pattern = content.substring(0, current); // the pattern
		String binaryCode = content.substring(current).trim(); // The message encoded

		Set<Character> chars = new HashSet<>();
		for (char c : pattern.toCharArray()) {
			if (c != '^') {
				chars.add(c);
			}
		}
		String chardict = chars.stream().map(String::valueOf).collect(Collectors.joining());

		// Call the edu.iastate.cs228.hw4.MsgTree method
		MsgTree root = new MsgTree(pattern);
		MsgTree.printCodes(root, chardict);
		root.decode(root, binaryCode);
	}
}