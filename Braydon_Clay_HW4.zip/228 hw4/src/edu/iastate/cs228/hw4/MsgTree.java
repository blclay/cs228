package edu.iastate.cs228.hw4;

import java.util.Stack;

/**
 * 
 * @author Braydon Clay
 *
 */
public class MsgTree {
	public char currentChar;
	public MsgTree left;
	public MsgTree right;
	// Static char is needed for the recursive solution
	private static int staticCharacterIndex = 0;

	/**
	 * Constructor building the tree from a string
	 * 
	 * @param encodingString string pulled from data file
	 */
	public MsgTree(String encodingString) {
		if (encodingString == null || encodingString.length() < 2) {
			return;
		}
		Stack<MsgTree> stack = new Stack<>();
		int currIndex = 0;
		this.currentChar = encodingString.charAt(currIndex++);
		stack.push(this);
		MsgTree current = this;
		String previousOpt = "in";
		while (currIndex < encodingString.length()) {
			MsgTree node = new MsgTree(encodingString.charAt(currIndex++));
			if (previousOpt.equals("in")) {
				current.left = node;
				if (node.currentChar == '^') {
					current = stack.push(node);
					previousOpt = "in";
				} else {
					if (!stack.empty())
						current = stack.pop();
					previousOpt = "out";
				}
			} else { // previousOpt is out
				current.right = node;
				if (node.currentChar == '^') {
					current = stack.push(node);
					previousOpt = "in";
				} else {
					if (!stack.empty())
						current = stack.pop();
					previousOpt = "out";
				}
			}
		}
	}

	/**
	 * Constructor for a single node with left and right null children
	 * 
	 * @param currentChar
	 */
	public MsgTree(char currentChar) {
		this.currentChar = currentChar;
		this.left = null;
		this.right = null;
	}

	/**
	 * Method to print characters and their binary codes
	 * 
	 * @param root
	 * @param code
	 */
	public static void printCodes(MsgTree root, String code) {
		System.out.println("character code\n-------------------------");
		for (char currCharacter : code.toCharArray()) {
			getCode(root, currCharacter, binCode = "");
			System.out.println("    " + (currCharacter == '\n' ? "\\n" : currCharacter + " ") + "    " + binCode);
		}
	}

	private static String binCode;

	/**
	 * Obtains the binary code and recursivly calls itself to set the alphabet
	 * 
	 * @param root
	 * @param currCharacter
	 * @param path
	 * @return
	 */
	private static boolean getCode(MsgTree root, char currCharacter, String path) {
		if (root != null) {
			if (root.currentChar == currCharacter) {
				binCode = path;
				return true;
			}
			return getCode(root.left, currCharacter, path + "0") || getCode(root.right, currCharacter, path + "1");
		}
		return false;
	}

	/**
	 * Decodes the message by using the alphabet from the pulled code
	 * 
	 * @param codes
	 * @param message
	 */
	public void decode(MsgTree codes, String message) {
		System.out.println("MESSAGE:");
		MsgTree current = codes;
		StringBuilder strBuilder = new StringBuilder();
		for (int i = 0; i < message.length(); i++) {
			char currCharacter = message.charAt(i);
			current = (currCharacter == '0' ? current.left : current.right);
			if (current.currentChar != '^') {
				getCode(codes, current.currentChar, binCode = "");
				strBuilder.append(current.currentChar);
				current = codes;
			}
		}
		System.out.println(strBuilder.toString());
		statistc(message, strBuilder.toString());
	}

	/**
	 * Extra credit statistics. Pulls the data of both the encoded and decoded strings to print
	 * 
	 * @param encodedString
	 * @param decodedString
	 */
	private void statistc(String encodedString, String decodedString) {
		System.out.println("STATISTICS:");
		System.out.println(String.format("Avg bits/char:\t%.1f", encodedString.length() / (double) decodedString.length()));
		System.out.println("Total Characters:\t" + decodedString.length());
		System.out.println(
				String.format("Space Saving:\t%.1f%%", (1d - decodedString.length() / (double) encodedString.length()) * 100));
	}
}