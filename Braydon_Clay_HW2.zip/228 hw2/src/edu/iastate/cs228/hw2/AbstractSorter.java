package edu.iastate.cs228.hw2;

import java.util.Comparator;

/**
 * This abstract class serves as the base class for sorting algorithms including SelectionSort, InsertionSort, MergeSort, and QuickSort.
 * It is responsible for storing and sorting an array of Point objects.
 *
 * @author Braydon Clay
 */
public abstract class AbstractSorter {
	
	protected Point[] points; // An array of points to be sorted.
	protected String sortingAlgorithm = null; // The name of the sorting algorithm.
	protected Comparator<Point> pointComparator = null; // A comparator used for sorting points.

	// Add other protected or private instance variables if needed.

	/**
	 * Default constructor for subclasses.
	 * No implementation needed. Provides a default super constructor to subclasses.
	 * Removable after implementing SelectionSorter, InsertionSorter, MergeSorter, and QuickSorter.
	 */
	protected AbstractSorter() {
		// No implementation needed.
	}

	/**
	 * Constructor that accepts an array of points as input and initializes the points array.
	 *
	 * @param pointsArray input array of points
	 * @throws IllegalArgumentException if pointsArray is null or empty.
	 */
	protected AbstractSorter(Point[] pointsArray) throws IllegalArgumentException {
		if (pointsArray == null || pointsArray.length == 0) {
			throw new IllegalArgumentException();
		}

		points = new Point[pointsArray.length];
		for (int i = 0; i < pointsArray.length; i++) {
			Point p = new Point(pointsArray[i]);
			points[i] = p;
		}
	}

	/**
	 * Generates a comparator on the fly that compares points by either x-coordinate or y-coordinate based on the specified order.
	 *
	 * @param order 0 for x-coordinate, 1 for y-coordinate
	 * @throws IllegalArgumentException if order is less than 0 or greater than 1
	 */
	public void setComparator(int order) throws IllegalArgumentException {

		for (int i = 0; i < points.length; i++) {
			// order of x
			if (order == 0) {
				pointComparator = new Comparator<Point>() {

					@Override
					public int compare(Point o1, Point o2) {
						Point.setXorY(true);
						return o1.compareTo(o2);
					}

				};
				// order of y
			} else if (order == 1) {
				pointComparator = new Comparator<Point>() {

					@Override
					public int compare(Point o1, Point o2) {
						Point.setXorY(false);
						return o1.compareTo(o2);
					}
				};
			}
		}
	}

	/**
	 * Sorts the array of points using the specified sorting algorithm.
	 * This method should be implemented by subclasses.
	 */
	public abstract void sort();

	/**
	 * Obtains the median point from the sorted array of points.
	 *
	 * @return the median point
	 */
	public Point getMedian() {
		return points[points.length / 2];
	}

	/**
	 * Copies the sorted points from the internal array to the specified pointsArray.
	 *
	 * @param pointsArray the array to store the sorted points
	 */
	public void getPoints(Point[] pointsArray) {
		for (int i = 0; i < points.length; i++) {
			Point p = new Point(points[i]);
			pointsArray[i] = p;
		}
	}

	/**
	 * Swaps two elements in the points array at the given indices i and j.
	 *
	 * @param i the index of the first element
	 * @param j the index of the second element
	 */
	protected void swap(int i, int j) {
		Point point1 = new Point(points[i]);
		Point point2 = new Point(points[j]);
		points[i] = point1;
		points[j] = point2;
	}
}
