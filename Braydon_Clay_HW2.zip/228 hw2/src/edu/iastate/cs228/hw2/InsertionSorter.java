package edu.iastate.cs228.hw2;

/**
 * This class implements insertion sort.
 * 
 * @author Braydon Clay
 */
public class InsertionSorter extends AbstractSorter {

	/**
	 * Constructor takes an array of points. It invokes the superclass constructor, and also sets the
	 * instance variable sortingAlgorithm in the superclass.
	 * 
	 * @param pointsArray the array of points to be sorted
	 */
	public InsertionSorter(Point[] pointsArray) {
		super(pointsArray);
		sortingAlgorithm = "Insertion Sort";
	}

	/**
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.
	 */
	@Override
	public void sort() {
		//int n = points.length;
		Point tempPoint;

		for (int i = 1; i < points.length; i++) {
			tempPoint = points[i];
			int j = i - 1;

			while (j > -1 && pointComparator.compare(points[j], tempPoint) > 0) {
				points[j + 1] = points[j];
				j--;
			}
			points[j + 1] = tempPoint;
		}
	}
}
