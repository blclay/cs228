package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random;

/**
 * This class compares the execution times of four sorting algorithms: number for selection sort, insertion sort, mergesort, and quicksort.
 * It applies these algorithms to both randomly generated integers and integers from a file input, evaluating their performance on the same input.
 * 
 * @author Braydon Clay
 */
public class CompareSorters {

	/**
	 * This process repeatedly takes integer sequences, either randomly generated or read from files,
	 * and constructs points using them as coordinates. It then scans these points four times, each time
	 * using a different sorting algorithm to determine the median coordinate point.
	 *
	 * @param args
	 * @throws FileNotFoundException if the specified file is not found
	 */
	public static void main(String[] args) throws FileNotFoundException {
		PointScanner[] multiScanner = new PointScanner[4];
		Point[] points;
		int currNumTrials = 1;
		int numForSelection = 1; // 1: random integers; 2: file input; 3 or any other number: exit
		int numOfRandomPoints = 1;

		System.out.println("Performances of Four Sorting Algorithms in Point Scanning\n");
		System.out.println("Enter: 1-(random integers)  2-(file input)  3-(exit)");

		Scanner singleScanner = new Scanner(System.in);
		while (numForSelection == 1 || numForSelection == 2) {
			System.out.print("Trial " + currNumTrials + ": ");
			numForSelection = singleScanner.nextInt();

			if (numForSelection == 1) {
				System.out.print("Enter number of random points: ");
				numOfRandomPoints = singleScanner.nextInt();
				points = new Point[numOfRandomPoints];
				Random fromRandomVar = new Random();
				points = generateRandomPoints(numOfRandomPoints, fromRandomVar);

				multiScanner[0] = new PointScanner(points, Algorithm.QuickSort);
				multiScanner[1] = new PointScanner(points, Algorithm.MergeSort);
				multiScanner[2] = new PointScanner(points, Algorithm.SelectionSort);
				multiScanner[3] = new PointScanner(points, Algorithm.InsertionSort);

				for (int i = 0; i < multiScanner.length; i++) {
					multiScanner[i].scan();
					multiScanner[i].writeMCPToFile();
				}
			} else if (numForSelection == 2) {

				System.out.println("Points taken from a file");
				System.out.print("File name: ");
				String fileName = singleScanner.next();

				multiScanner[0] = new PointScanner(fileName, Algorithm.QuickSort);
				multiScanner[1] = new PointScanner(fileName, Algorithm.MergeSort);
				multiScanner[2] = new PointScanner(fileName, Algorithm.SelectionSort);
				multiScanner[3] = new PointScanner(fileName, Algorithm.InsertionSort);

				for (int i = 0; i < multiScanner.length; i++) {
					multiScanner[i].scan();
					multiScanner[i].writeMCPToFile();
				}
			} else {
				singleScanner.close();
				break;
			}

			System.out.println("\nAlgoritm used   size   time(in nanoseconds)\n-------------------------------");
			for (int i = 0; i < multiScanner.length; i++) {
				System.out.println(multiScanner[i].stats());
			}
			System.out.println("-------------------------------\n");
			currNumTrials++;
		}
	}

	/**
	 * Generates a given number of random points.
	 * The coordinates of these points are pseudo-random numbers within the range
	 * [-50, 50] × [-50, 50].
	 *
	 * @param numPoints   number of points
	 * @param fromRandVariable   Random object to allow seeding of the random number generator
	 * @return an array of randomly generated points
	 * @throws IllegalArgumentException if numPoints is less than 1
	 */
	public static Point[] generateRandomPoints(int numPoints, Random fromRandVariable) throws IllegalArgumentException {
		if (numPoints < 1) {
			throw new IllegalArgumentException("Must enter 1 or more points!");
		}

		Point[] randomPoints = new Point[numPoints];
		for (int i = 0; i < numPoints; i++) {
			randomPoints[i] = new Point(fromRandVariable.nextInt(101) - 50, fromRandVariable.nextInt(101) - 50);
		}

		return randomPoints;
	}
}
