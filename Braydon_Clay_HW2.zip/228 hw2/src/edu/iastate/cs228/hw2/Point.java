package edu.iastate.cs228.hw2;

/**
 * This class represents a point with x and y coordinates.
 * It also provides methods for comparison and string representation.
 * 
 * @author Braydon Clay
 */
public class Point implements Comparable<Point> {
	private int x;
	private int y;

	/**
	 * Static boolean variable that determines whether comparisons are made based on x coordinates (true) or y coordinates (false).
	 */
	public static boolean xORy;

	/**
	 * Default constructor. Initializes both x and y to 0.
	 */
	public Point() {
		x = 0;
		y = 0;
	}

	/**
	 * Constructor that sets the x and y coordinates of the point.
	 * 
	 * @param x the x-coordinate
	 * @param y the y-coordinate
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Copy constructor. Creates a new Point object with the same x and y coordinates as the provided point.
	 * 
	 * @param point the point to copy
	 */
	public Point(Point point) {
		x = point.getX();
		y = point.getY();
	}

	/**
	 * Get the x-coordinate of the point.
	 * 
	 * @return the x-coordinate
	 */
	public int getX() {
		return x;
	}

	/**
	 * Get the y-coordinate of the point.
	 * 
	 * @return the y-coordinate
	 */
	public int getY() {
		return y;
	}

	/**
	 * Set the value of the static instance variable xORy, which determines whether comparisons are made based on x or y coordinates.
	 * 
	 * @param xORy true to compare x coordinates, false to compare y coordinates
	 */
	public static void setXorY(boolean xORy) {
		Point.xORy = xORy;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != this.getClass()) {
			return false;
		}

		Point other = (Point) obj;
		return x == other.x && y == other.y;
	}
	
	/**
	 * Compare this point with another point based on the value of the static variable xORy.
	 * 
	 * @param comparedPoint the point to compare with
	 * @return -1 if (xORy == true && (this.x < comparedPoint.x || (this.x == comparedPoint.x && this.y < comparedPoint.y)))
	 *         -1 if (xORy == false && (this.y < comparedPoint.y || (this.y == comparedPoint.y && this.x < comparedPoint.x)))
	 *         0 if this point is equal to the comparedPoint
	 *         1 otherwise
	 */
	@Override
	public int compareTo(Point comparedPoint) {
		if (xORy == true && (this.x < comparedPoint.x || (this.x == comparedPoint.x && this.y < comparedPoint.y))
				|| xORy == false && (this.y < comparedPoint.y || (this.y == comparedPoint.y && this.x < comparedPoint.x))) {
			return -1;
		} else if (this.x == comparedPoint.x && this.y == comparedPoint.y) {
			return 0;
		} else {
			return 1;
		}
	}

	/**
	 * Return a string representation of the point in the standard form (x, y).
	 * 
	 * @return the string representation of the point
	 */
	@Override
	public String toString() {
		return "(" + x + ", " + y + ")";
	}
}
