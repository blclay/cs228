package edu.iastate.cs228.hw2;

/**
 * This class implements the mergesort sorting algorithm.
 * 
 * @author Braydon Clay
 */
public class MergeSorter extends AbstractSorter {
	// Other private instance variables if needed

	/**
	 * Constructor takes an array of points. It invokes the superclass constructor and sets the
	 * instance variable sortingAlgorithm in the superclass.
	 * 
	 * @param pointsArray the array of points to be sorted
	 */
	public MergeSorter(Point[] pointsArray) {
		super(pointsArray);
		sortingAlgorithm = "Merge Sort";
	}

	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter.
	 */
	@Override
	public void sort() {
		recursiveMergeSort(points);
	}

	/**
	 * This recursive method performs mergesort on an array pointsArray[] of points.
	 * It involves making copies of the two halves of pointsArray[], recursively calling mergeSort on them,
	 * and then merging the two sorted subarrays into pointsArray[].
	 * 
	 * @param pointsArray point array
	 */
	private void recursiveMergeSort(Point[] pointsArray) {

		int arraySize = pointsArray.length;
		if (arraySize < 2) {
			return;
		}

		int midpoint = arraySize / 2;
		Point[] leftArray = new Point[midpoint];
		Point[] rightArray = new Point[arraySize - midpoint];

		for (int i = 0; i < midpoint; i++) {
			leftArray[i] = pointsArray[i];
		}

		for (int i = midpoint; i < arraySize; i++) {
			rightArray[i - midpoint] = pointsArray[i];
		}

		recursiveMergeSort(leftArray);
		recursiveMergeSort(rightArray);
		merge(pointsArray, leftArray, rightArray);

	}

	/**
	 * Merge two sorted arrays, leftArray and rightArray, into the pointsArray.
	 * 
	 * @param pointsArray the array to merge into
	 * @param leftArray   the left half of the array
	 * @param rightArray  the right half of the array
	 */
	private void merge(Point[] pointsArray, Point[] leftArray, Point[] rightArray) {

		int leftSize = leftArray.length;
		int rightSize = rightArray.length;
		int iteratorLeft = 0, iteratorRight = 0, iteratorMerged = 0; // iteratorLeft for leftArray, iteratorRight for rightArray, iteratorMerged for pointsArray

		while (iteratorLeft < leftSize && iteratorRight < rightSize) {
			if (pointComparator.compare(leftArray[iteratorLeft], rightArray[iteratorRight]) < 0) {
				pointsArray[iteratorMerged] = leftArray[iteratorLeft];
				iteratorLeft++;
			} else {
				pointsArray[iteratorMerged] = rightArray[iteratorRight];
				iteratorRight++;
			}
			iteratorMerged++;
		}
		// copying the array leftArray[iteratorLeft] into pointsArray[iteratorMerged] for the rest of left length. Same for right half.
		System.arraycopy(leftArray, iteratorLeft, pointsArray, iteratorMerged, leftArray.length - iteratorLeft);
		System.arraycopy(rightArray, iteratorRight, pointsArray, iteratorMerged, rightArray.length - iteratorRight);

		}
	}
