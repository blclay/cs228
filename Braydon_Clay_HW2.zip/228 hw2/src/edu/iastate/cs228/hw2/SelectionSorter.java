package edu.iastate.cs228.hw2;

/**
 * This class implements the Selection Sort sorting algorithm.
 *
 * @author Braydon Clay
 */
public class SelectionSorter extends AbstractSorter {
    // Other private instance variables if you need ...

    /**
     * The constructor initializes an array of points, calls the superclass constructor, 
     * and sets the sortingAlgorithm instance variable in the superclass.
     *
     * @param pointsArray input array of points
     */
    public SelectionSorter(Point[] pointsArray) {
        super(pointsArray);
        sortingAlgorithm = "Selection Sort";
    }

    /**
     * Apply selection sort on the array points[] of the parent class AbstractSorter.
     */
    @Override
    public void sort() {
        for (int i = 0; i < points.length - 1; i++) {
            int indexOfMinimum = i;
            for (int j = i + 1; j < points.length; j++) {
                if (pointComparator.compare(points[j], points[indexOfMinimum]) == -1) {
                    indexOfMinimum = j;
                }
            }
            swap(i, indexOfMinimum);
        }
    }
}
