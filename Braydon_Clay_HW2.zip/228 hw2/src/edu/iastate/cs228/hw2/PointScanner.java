package edu.iastate.cs228.hw2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *This class determines a reference point for a given array of 2D points by calculating the medians of their x and y coordinates.
 *It also records the sorting algorithm used and the sorting time for comparison purposes.
 *
 * @author Braydon Clay
 */
public class PointScanner {
    private Point[] pointsArray;
    private Point medianCoordinatePoint;
    private Algorithm sortingAlgorithm;
    protected long scanTime;
    protected String outputFileName;

    /**
     * Constructs a PointScanner object with an array of points and a sorting algorithm.
     *
     * @param pointsArray The input array of points.
     * @param algorithm   The sorting algorithm to use.
     * @throws IllegalArgumentException If pointsArray is null or empty.
     */
    public PointScanner(Point[] pointsArray, Algorithm algorithm) throws IllegalArgumentException {
        if (pointsArray == null || pointsArray.length == 0) {
            throw new IllegalArgumentException("Points array cannot be null or empty.");
        }

        sortingAlgorithm = algorithm;
        setOutputFileName();
        this.pointsArray = new Point[pointsArray.length];
        System.arraycopy(pointsArray, 0, this.pointsArray, 0, pointsArray.length);
    }

    /**
     * Constructs a PointScanner object by reading points from a file.
     *
     * @param inputFileName The name of the input file.
     * @param algorithm     The sorting algorithm to use.
     * @throws FileNotFoundException     If the input file is not found.
     * @throws InputMismatchException    If the input file contains an odd number of integers.
     */
    protected PointScanner(String inputFileName, Algorithm algorithm)
            throws FileNotFoundException, InputMismatchException {
        sortingAlgorithm = algorithm;
        setOutputFileName();
        File file = new File(inputFileName);
        Scanner countingScanner = new Scanner(file);
        int numberOfIntegers = 0;

        while (countingScanner.hasNextInt()) {
            countingScanner.nextInt();
            numberOfIntegers++;
        }

        countingScanner.close();

        if (numberOfIntegers % 2 != 0) {
            throw new InputMismatchException("Input file must contain an even number of integers.");
        }

        Scanner numScanner = new Scanner(file);
        pointsArray = new Point[numberOfIntegers / 2];
        int i = 0;

        while (numScanner.hasNextInt()) {
            pointsArray[i] = new Point(numScanner.nextInt(), numScanner.nextInt());
            i++;
        }

        numScanner.close();
    }
    // this is a helper method to name the file based on the sort
    private void setOutputFileName() {
        switch (sortingAlgorithm) {
            case SelectionSort:
                outputFileName = "selectionsort.txt";
                break;
            case InsertionSort:
                outputFileName = "insertionsort.txt";
                break;
            case MergeSort:
                outputFileName = "mergesort.txt";
                break;
            case QuickSort:
                outputFileName = "quicksort.txt";
                break;
        }
    }
    
    
    /**
     * Sorts the pointsArray by x-coordinate and then by y-coordinate to determine the medianCoordinatePoint.
     * The execution time is recorded and written to the user.
     */
    public void scan() {
        AbstractSorter abstractSorter = getSorterInstance();

        // Sort by x-coordinate
        long startingXSortingTime = System.nanoTime();
        abstractSorter.setComparator(0);
        abstractSorter.sort();
        int medianX = abstractSorter.getMedian().getX();
        long endingXSortingTime = System.nanoTime() - startingXSortingTime;

        // Sort by y-coordinate
        long startingYSortingTime = System.nanoTime();
        abstractSorter.setComparator(1);
        abstractSorter.sort();
        int medianY = abstractSorter.getMedian().getY();
        long endingYSortingTime = System.nanoTime() - startingYSortingTime;

        medianCoordinatePoint = new Point(medianX, medianY);
        scanTime = endingXSortingTime + endingYSortingTime;
    }
    
    // this is a helper method to set an instance based on the algorithm given
    private AbstractSorter getSorterInstance() {
        AbstractSorter abstractSorter = null;

        switch (sortingAlgorithm) {
            case SelectionSort:
                abstractSorter = new SelectionSorter(pointsArray);
                break;
            case InsertionSort:
                abstractSorter = new InsertionSorter(pointsArray);
                break;
            case MergeSort:
                abstractSorter = new MergeSorter(pointsArray);
                break;
            case QuickSort:
                abstractSorter = new QuickSorter(pointsArray);
                break;
        }

        return abstractSorter;
    }

    /**
     * Returns performance statistics in the format: "<sortingAlgorithm> <size> <time>".
     *
     * @return The performance statistics.
     */
    public String stats() {
        return String.format("%-13s", sortingAlgorithm) + "    " + pointsArray.length + "    " + scanTime;
    }

    /**
     * Returns the medianCoordinatePoint in the format "MCP: (x, y)".
     *
     * @return The medianCoordinatePoint as a string.
     */
    @Override
    public String toString() {
        return "MCP: (" + medianCoordinatePoint.getX() + ", " + medianCoordinatePoint.getY() + ")";
    }

    /**
     * Writes the medianCoordinatePoint to a file.
     *
     * @throws FileNotFoundException If the output file cannot be created.
     */
    public void writeMCPToFile() throws FileNotFoundException {
        File outputFile = new File(outputFileName);
        PrintWriter writer = new PrintWriter(outputFile);
        writer.print(this.toString());
        writer.close();
    }



   
}
