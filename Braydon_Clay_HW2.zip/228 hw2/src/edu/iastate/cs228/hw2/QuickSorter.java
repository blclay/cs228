package edu.iastate.cs228.hw2;

/**
 * This class implements the Quick Sort sorting algorithm
 *
 * @author Braydon Clay
 */
public class QuickSorter extends AbstractSorter {

    /**
     * The constructor accepts an array of points, calls the superclass constructor, 
     * and assigns the sortingAlgorithm instance variable in the superclass.
     *
     * @param pointsArray input array of points
     */
    public QuickSorter(Point[] pointsArray) {
        super(pointsArray);
        sortingAlgorithm = "Quick Sort";
    }

    /**
     * Operates on the subarray of points[] with indices between indexFirst and indexLast.
     *
     * @param indexFirst starting index of the subarray
     * @param indexLast  ending index of the subarray
     * @return the index of the pivot element
     */
    private int partition(int indexFirst, int indexLast) {
        Point pivot = points[indexLast];
        int i = indexFirst - 1;
        for (int j = indexFirst; j < indexLast; j++) {
            if (pointComparator.compare(points[j], pivot) < 1) {
                i++;
                swap(i, j);
            }
        }
        swap(i + 1, indexLast);
        return i + 1;
    }
    
    /**
     * Carry out Quick Sort on the array points[] of the AbstractSorter class.
     */
    @Override
    public void sort() {
        quickSortRecursive(0, points.length - 1);
    }

    /**
     * Operates on the subarray of points[] with indices between indexFirst and indexLast.
     *
     * @param indexFirst starting index of the subarray
     * @param indexLast  ending index of the subarray
     */
    private void quickSortRecursive(int indexFirst, int indexLast) {
        if (indexFirst >= indexLast) {
            return;
        }
        int p = partition(indexFirst, indexLast);
        quickSortRecursive(indexFirst, p - 1);
        quickSortRecursive(p + 1, indexLast);
    }
}
